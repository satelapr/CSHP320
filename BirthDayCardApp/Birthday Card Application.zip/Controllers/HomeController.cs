﻿using BirthdayCardApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace BirthdayCardApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            BirthDayCardModel birthDayCardModel = new BirthDayCardModel();
            birthDayCardModel.DisplayInputFlag = true;
            return View(birthDayCardModel);
        }

        [HttpPost]
        public IActionResult SendCard(BirthDayCardModel birthDayCardModel)
        {
            if (ModelState.IsValid)
            {
                birthDayCardModel.DisplayInputFlag = false;
            }
            else birthDayCardModel.DisplayInputFlag = true;

            return View("Index", birthDayCardModel);
        }

     
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
