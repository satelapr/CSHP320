﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerAccessoryInventory.Models
{
    public class InventoryItem
    {
        public int ItemNo { get; set; }

        public string Description { get; set; }

        public double ItemPrice { get; set; }

        public int Quantity { get; set; }

        public double ItemCost { get; set; }

        public double ItemValue { get; set; }
    }
}
